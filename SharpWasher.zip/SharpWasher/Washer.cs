﻿namespace SharpWasher
{
    public delegate void Washer(Car car);
}
